import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
import {atomicJson,taipeiWeek,mergeRecords,parsePost,fetchPublic,discoverPostUrls,validateRecord,digest} from './lib.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),dir=path.join(root,'updater'),state=path.join(dir,'state');fs.mkdirSync(state,{recursive:true});
const read=(p,fallback)=>{try{return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''))}catch(e){if(e.code==='ENOENT')return fallback;throw e}};
const config=()=>({...read(path.join(dir,'config.example.json'),{}),...read(path.join(dir,'config.local.json'),{})});
const log=o=>{const row={at:new Date().toISOString(),...o};console.log(JSON.stringify(row));fs.appendFileSync(path.join(state,'events.jsonl'),JSON.stringify(row)+'\n')};
function git(args){const r=spawnSync('git',args,{cwd:root,encoding:'utf8',timeout:60000,env:{...process.env,GIT_TERMINAL_PROMPT:'0'}});if(r.status!==0)throw Error('git-'+args[0]+'-failed');return r.stdout.trim();}
function publish(c){const remote=git(['remote','get-url',c.githubRemote]);if(!/^(https:\/\/github\.com\/|git@github\.com:)[\w.-]+\/[\w.-]+(?:\.git)?$/.test(remote))throw Error('github-remote-not-configured');if(git(['branch','--show-current'])!==c.githubBranch)throw Error('wrong-github-branch');git(['add','--','dist/stores.json','dist/weeks']);if(git(['diff','--cached','--name-only']).split('\n').filter(Boolean).some(p=>!/^dist\/(stores\.json|weeks\/)/.test(p)))throw Error('unrelated-staged-changes');if(git(['diff','--cached','--name-only']))git(['commit','-m','Update weekly draw data']);git(['push',c.githubRemote,c.githubBranch]);return 'pushed-awaiting-pages';}
export async function cycle({fetcher}={}){
 const c=config(),week=c.week==='auto'?taipeiWeek():c.week;if(!/^\d{4}-\d{2}-\d{2}$/.test(week))throw Error('invalid-week');
 const stores=read(path.join(root,'dist/stores.json'),{}).stores||[],sources=read(path.join(dir,'sources.json'),{sources:[]}).sources;
 const file=path.join(root,'dist/weeks',week+'.json'),old=read(file,{schemaVersion:1,week,records:[]});let records=old.records;const statuses=[];
 const imports=path.join(dir,'imports');fs.mkdirSync(imports,{recursive:true});
 // Imported post text is an explicit fallback for public content not returned by Facebook.
 for(const filename of fs.readdirSync(imports).filter(n=>n.endsWith('.json'))){try{const doc=read(path.join(imports,filename));const store=stores.find(s=>s.id===doc.storeId);if(!store||!/^https:\/\/(www\.|m\.)?facebook\.com\//.test(doc.sourceUrl))throw Error('invalid-import-source');let p;if(doc.records){p={status:'manual-reviewed',records:doc.records.map(r=>validateRecord({...r,storeId:store.id,storeName:store.name,region:store.region,sourceUrl:doc.sourceUrl,sourceType:'facebook-manual-reviewed',parseStatus:'manual-reviewed',fetchedAt:new Date().toISOString()})).filter(r=>r.week===week)};}else p=parsePost(doc.text,{store,sourceUrl:doc.sourceUrl,week});records=mergeRecords(records,p.records);statuses.push({sourceUrl:doc.sourceUrl,storeId:store.id,status:p.status,count:p.records.length,fetchedAt:new Date().toISOString()});}catch(e){statuses.push({file:filename,status:'import-failed',error:e.message});}}
 for(const source of sources.filter(s=>s.enabled!==false)){
   const store=stores.find(s=>s.id===source.storeId);const status={storeId:source.storeId,sourceUrl:source.url,fetchedAt:new Date().toISOString(),status:'pending',count:0};
   try{
    if(!store)throw Error('unknown-store');let page;
    for(let retry=0;retry<2;retry++){try{page=await fetchPublic(source.url,{fetcher,timeoutMs:c.requestTimeoutMs});break}catch(e){if(retry===1)throw e;}}
    const urls=source.kind==='post'?[source.url]:discoverPostUrls(page.html,source.url).slice(0,c.maxPostsPerSource||10);
    if(!urls.length){status.status='no-readable-public-posts';}
    else {let reviews=0,failed=0;for(const url of urls){try{const post=url===source.url?page:await fetchPublic(url,{fetcher,timeoutMs:c.requestTimeoutMs});for(const text of post.texts){const parsed=parsePost(text,{store,sourceUrl:url,week});atomicJson(path.join(state,'parsed',digest(url)+'.json'),{sourceUrl:url,storeId:store.id,fetchedAt:new Date().toISOString(),text,parseStatus:parsed.status,records:parsed.records});records=mergeRecords(records,parsed.records);status.count+=parsed.records.length;if(parsed.status.startsWith('needs-review')||parsed.status.startsWith('partial'))reviews++;}if(!post.texts.length)reviews++;}catch(e){failed++;log({type:'post-failed',sourceUrl:url,error:e.message});}}
      status.status=failed?'partial-fetch-failed':reviews?'needs-review':status.count?'parsed':'no-current-week-records';status.reviewCount=reviews;status.failedPosts=failed;
    }
   }catch(e){status.status='fetch-failed';status.error=e.message;}
   statuses.push(status);log({type:'source',...status});
 }
 const changed=JSON.stringify(records)!==JSON.stringify(old.records);
 if(changed){atomicJson(file,{...old,updatedAt:new Date().toISOString(),records});const indexFile=path.join(root,'dist/weeks/index.json');const index=read(indexFile,{schemaVersion:1,weeks:[]});index.weeks=[...new Set([...index.weeks,week])].sort().reverse();index.latest=index.weeks[0];atomicJson(indexFile,index);}
 const configured=new Set(sources.filter(s=>s.enabled!==false).map(s=>s.storeId));
 const report={at:new Date().toISOString(),week,changed,records:records.length,sources:statuses,coverage:{totalStores:stores.length,configuredStores:configured.size,missingStores:stores.filter(s=>!configured.has(s.id)).map(s=>({id:s.id,name:s.name,region:s.region}))},publication:c.publish?'pending':'disabled'};
 // Retry publication even without new records, so offline Git pushes recover next cycle.
 if(c.publish){try{report.publication=publish(c);}catch(e){report.publication='failed';report.publishError=e.message;}}
 atomicJson(path.join(state,'status.json'),report);log({type:'cycle',week,changed,records:records.length,publication:report.publication,configuredStores:configured.size});return report;
}
async function main(){const lock=path.join(state,'updater.lock');let fd;try{fd=fs.openSync(lock,'wx');fs.writeFileSync(fd,String(process.pid));}catch{let pid=Number(fs.readFileSync(lock,'utf8'));try{process.kill(pid,0);throw Error('already-running')}catch(e){if(e.code!=='ESRCH')throw e;fs.unlinkSync(lock);return main();}}
let stop=false;process.on('SIGINT',()=>stop=true);process.on('SIGTERM',()=>stop=true);try{do{try{await cycle()}catch(e){log({type:'cycle-failed',error:e.message});}if(process.argv.includes('--once'))break;const seconds=Math.max(60,Math.min(3600,Number(config().intervalSeconds)||240));for(let i=0;i<seconds&&!stop;i++){if(fs.existsSync(path.join(state,'stop'))){stop=true;break;}await new Promise(r=>setTimeout(r,1000));}}while(!stop);}finally{fs.closeSync(fd);fs.unlinkSync(lock);if(fs.existsSync(path.join(state,'stop')))fs.unlinkSync(path.join(state,'stop'));}}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1});
