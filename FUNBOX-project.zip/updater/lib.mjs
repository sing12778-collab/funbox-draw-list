import crypto from 'node:crypto';import fs from 'node:fs';import path from 'node:path';
export const digest=s=>crypto.createHash('sha256').update(s).digest('hex').slice(0,16);
export function atomicJson(file,value){fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+process.pid+'.tmp';fs.writeFileSync(temp,JSON.stringify(value,null,2)+'\n');fs.renameSync(temp,file);}
export function taipeiWeek(now=new Date()){const day=now.toLocaleDateString('en-CA',{timeZone:'Asia/Taipei'});const date=new Date(day+'T00:00:00Z');date.setUTCDate(date.getUTCDate()-((date.getUTCDay()+6)%7));return date.toISOString().slice(0,10);}
export function validLine(url){try{const u=new URL(url);return u.protocol==='https:'&&['lin.ee','liff.line.me'].includes(u.hostname)}catch{return false}}
export function validateRecord(r){if(!r.id||!r.storeId||!r.storeName||!r.region||!/^\d{4}-\d{2}-\d{2}$/.test(r.week)||!validLine(r.lineUrl)||!/^(BXG|UX|BX|CX)-\d+$/.test(r.productCode))throw Error('invalid-record');if(!/^https:\/\//.test(r.sourceUrl||''))throw Error('missing-source');return r;}
export function mergeRecords(oldRecords,newRecords){const key=r=>r.storeId+'|'+r.lineUrl+'|'+r.productCode;const map=new Map(oldRecords.map(r=>[key(r),r]));for(const r of newRecords){validateRecord(r);const k=key(r);const old=map.get(k);if(old){const meaningful=x=>JSON.stringify({...x,fetchedAt:null});if(meaningful({...old,...r,id:old.id})===meaningful(old))continue;map.set(k,{...old,...r,id:old.id});}else map.set(k,r);}return [...map.values()];}
export function decode(s){return s.replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))).replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(+n)).replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&nbsp;/g,' ');}
export function postTexts(html){const out=[];for(const m of html.matchAll(/"(?:text|message)"\s*:\s*("(?:\\.|[^"\\])*")/g)){try{out.push(JSON.parse(m[1]))}catch{}}for(const m of html.matchAll(/<meta[^>]+(?:property|name)=["'](?:og:description|description)["'][^>]+content=["']([^"']*)["']/gi))out.push(decode(m[1]));return [...new Set(out)].filter(t=>/(?:BXG|UX|BX|CX)-\d+/i.test(t)&&/lin\.ee|liff\.line\.me/.test(t));}
export function discoverPostUrls(html,base){const result=new Set();for(const m of decode(html).replace(/\\\//g,'/').matchAll(/(?:https:\/\/(?:www\.)?facebook\.com)?\/[A-Za-z0-9_.-]+\/posts\/[A-Za-z0-9]+\/?/g)){try{const u=new URL(m[0],base);if(u.hostname.endsWith('facebook.com'))result.add(u.href)}catch{}}return [...result];}
export function parsePost(text,{store,sourceUrl,week,fetchedAt=new Date().toISOString()}){
  // Conservative: a full date and one model/URL per line or adjacent line are required.
  const dateMatches=[...text.matchAll(/(20\d{2})[\/年.-](\d{1,2})[\/月.-](\d{1,2})日?\s*(?:(\d{1,2})[:：](\d{2}))?/g)];
  if(!dateMatches.length)return {records:[],status:'needs-review-date',reason:'No explicit year/date; no guessed current-week assignment.'};
  const dates=dateMatches.map(m=>{const date=`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;const time=m[4]?`${m[4].padStart(2,'0')}:${m[5]}`:null;return {date,time,iso:time?date+'T'+time+':00+08:00':null};});
  if(dates.some(d=>{const n=new Date(d.date+'T00:00:00Z');return !Number.isFinite(+n)||n.toISOString().slice(0,10)!==d.date||(d.time&&(Number(d.time.slice(0,2))>23||Number(d.time.slice(3))>59));}))return {records:[],status:'needs-review-invalid-date'};
  if(dates[0]?.iso&&dates[1]?.iso&&dates[1].iso<dates[0].iso)return {records:[],status:'needs-review-invalid-period'};
  const begin=dates[0],end=dates[1];const weekStart=new Date(week+'T00:00:00+08:00');const weekEnd=new Date(+weekStart+7*86400000);const begins=new Date(begin.date+'T00:00:00+08:00');
  if(!(begins>=weekStart&&begins<weekEnd))return {records:[],status:'outside-week'};
  if(dates.length>2)return {records:[],status:'needs-review-multiple-periods'};
  const lines=text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean),records=[];let unresolved=0;
  for(let i=0;i<lines.length;i++){
    const urls=[...lines[i].matchAll(/https:\/\/(?:lin\.ee|liff\.line\.me)\/[A-Za-z0-9_/?=&%.-]+/g)].map(m=>m[0]);if(!urls.length)continue;
    const context=/(?:BXG|UX|BX|CX)-\d+/i.test(lines[i])?lines[i]:(lines[i-1]||'');const codes=[...new Set((context.match(/(?:BXG|UX|BX|CX)-\d+/gi)||[]).map(s=>s.toUpperCase()))];
    if(urls.length!==1||codes.length!==1){unresolved++;continue;}
    const lineUrl=urls[0];const productName=context.replace(/https:\/\/\S+/g,'').trim();
    records.push({id:'r-'+digest(store.id+'|'+lineUrl+'|'+codes[0]),storeId:store.id,storeName:store.name,region:store.region,productCode:codes[0],productName,startTime:begin.time||(/開店/.test(text)?'開店':'未知'),startsAt:begin.iso,endsAt:end?.iso||null,periodText:dateMatches.map(m=>m[0]).join(' ～ '),lineUrl,sourceUrl,sourceType:'facebook-public-post',fetchedAt,parseStatus:'parsed',week});
  }
  return {records,status:records.length?(unresolved?'partial-needs-review':'parsed'):'needs-review-pairing',unresolved};
}
export async function fetchPublic(url,{fetcher=fetch,timeoutMs=15000}={}){
  const u=new URL(url);if(u.protocol!=='https:'||!['facebook.com','www.facebook.com','m.facebook.com'].includes(u.hostname))throw Error('unsupported-public-source');
  const r=await fetcher(u,{signal:AbortSignal.timeout(timeoutMs),headers:{'User-Agent':'FunboxDrawUpdater/0.3 (public announcements)'},redirect:'follow'});
  if(!r.ok)throw Error('http-'+r.status);if(!['facebook.com','www.facebook.com','m.facebook.com'].includes(new URL(r.url||u).hostname))throw Error('unexpected-redirect');
  const html=await r.text();if(html.length>15000000)throw Error('source-too-large');
  const texts=postTexts(html);if(!texts.length&&/login_form|You must log in|登入 Facebook|Log Into Facebook|checkpoint|temporarily blocked/i.test(html))throw Error('login-or-access-required');
  return {html,texts};
}
