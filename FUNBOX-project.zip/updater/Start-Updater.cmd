@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -STA -WindowStyle Hidden -File "%~dp0Updater.ps1"
