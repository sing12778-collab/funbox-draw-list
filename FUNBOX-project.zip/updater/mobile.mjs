import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {atomicJson} from './lib.mjs';
export function mobileSnapshot(stores,weekData,overrides={}){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(weekData.week)||!Array.isArray(weekData.records)||!weekData.records.length)throw Error('empty-or-invalid-week');
 const byStore=new Map(stores.map(s=>[s.id,s]));const ids=new Set();
 const records=weekData.records.map(r=>{const store=byStore.get(r.storeId);if(!store||!r.id||ids.has(r.id)||!r.productCode||!r.region||!r.storeName)throw Error('invalid-mobile-record');ids.add(r.id);const url=new URL(r.lineUrl);if(url.protocol!=='https:'||!['lin.ee','liff.line.me'].includes(url.hostname)||url.username||url.password)throw Error('invalid-mobile-url');const extra=overrides[r.id];return {...r,lineId:store.lineId||'',...(extra?.lineUrl===r.lineUrl&&extra?.week===weekData.week?extra.fields:{})};});
 return {schemaVersion:1,week:weekData.week,updatedAt:weekData.updatedAt,records};
}
export function writeMobile(root){const dist=path.join(root,'dist');const read=f=>JSON.parse(fs.readFileSync(path.join(dist,f),'utf8').replace(/^\uFEFF/,''));const index=read('weeks/index.json');const data=read('weeks/'+index.latest+'.json');let overrides={};try{overrides=read('mobile-overrides.json')}catch(e){if(e.code!=='ENOENT')throw e;}
 const snapshot=mobileSnapshot(read('stores.json').stores,data,overrides);const bytes=Buffer.from(JSON.stringify(snapshot)+'\n');const sha256=crypto.createHash('sha256').update(bytes).digest('hex');const name=sha256+'.json';const dir=path.join(dist,'mobile');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,name);if(!fs.existsSync(file))fs.writeFileSync(file,bytes,{flag:'wx'});
 const manifest={schemaVersion:1,week:snapshot.week,updatedAt:snapshot.updatedAt,snapshot:name,sha256,records:snapshot.records.length};let old;try{old=JSON.parse(fs.readFileSync(path.join(dir,'index.json'),'utf8'))}catch{}if(old?.sha256!==sha256)atomicJson(path.join(dir,'index.json'),manifest);return manifest;
}

