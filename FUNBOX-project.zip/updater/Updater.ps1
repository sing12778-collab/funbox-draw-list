﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System; using System.Runtime.InteropServices;
public class KeepAwake { [DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint flags); }
'@
$taskRoot = Split-Path $PSScriptRoot -Parent
$stateDir = Join-Path $PSScriptRoot 'state'
New-Item -ItemType Directory -Force $stateDir | Out-Null
$script:worker = $null
$form = New-Object System.Windows.Forms.Form
$form.Text = 'FUNBOX／來玩聚 資料更新器'
$form.Size = New-Object System.Drawing.Size(750,620)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Microsoft JhengHei',10)
$label = New-Object System.Windows.Forms.Label
$label.Text = '每隔幾秒檢查（預設 240 秒＝4 分鐘）：'
$label.SetBounds(20,20,440,30)
$interval = New-Object System.Windows.Forms.NumericUpDown
$interval.Minimum = 60; $interval.Maximum = 3600; $interval.Value = 240
$interval.SetBounds(465,20,120,30)
$publish = New-Object System.Windows.Forms.CheckBox
$publish.Text = '成功更新後推送 GitHub（須先完成儲存庫與 Git 登入設定）'
$publish.SetBounds(20,60,680,30)
$start = New-Object System.Windows.Forms.Button
$start.Text = '開始持續更新'; $start.SetBounds(20,105,170,40)
$stop = New-Object System.Windows.Forms.Button
$stop.Text = '停止更新'; $stop.SetBounds(200,105,130,40)
$sources = New-Object System.Windows.Forms.Button
$sources.Text = '編輯來源'; $sources.SetBounds(340,105,130,40)
$open = New-Object System.Windows.Forms.Button
$open.Text = '開啟紀錄資料夾'; $open.SetBounds(480,105,200,40)
$info = New-Object System.Windows.Forms.Label
$info.Text = '尚未啟動。請先補齊門市來源；只會解析能公開讀取的貼文。'
$info.SetBounds(20,160,690,65)
$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true; $log.ReadOnly = $true; $log.ScrollBars = 'Vertical'
$log.SetBounds(20,230,690,265); $log.Anchor = 'Top,Bottom,Left,Right'
$hint = New-Object System.Windows.Forms.Label
$hint.Text = '執行期間請保持電腦開機、供電及連網。最小化不會停止。停止或斷線不刪除網站既有資料。關機／休眠／登出會中斷；重新啟動可繼續。'
$hint.SetBounds(20,505,690,65); $hint.Anchor = 'Bottom,Left,Right'
$form.Controls.AddRange(@($label,$interval,$publish,$start,$stop,$sources,$open,$info,$log,$hint))
$configPath = Join-Path $PSScriptRoot 'config.local.json'
if(Test-Path -LiteralPath $configPath){try{$saved=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json;$interval.Value=[Math]::Max(60,[Math]::Min(3600,$saved.intervalSeconds));$publish.Checked=[bool]$saved.publish}catch{}}
$start.Add_Click({
 try {
  if($script:worker -and -not $script:worker.HasExited){return}
  $nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
  $nodePath = if($nodeCommand){$nodeCommand.Source}else{Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'}
  if(-not(Test-Path -LiteralPath $nodePath)){throw '請先安裝 Node.js 22 或更新版本（nodejs.org），再啟動更新器。'}
  $settings=Get-Content (Join-Path $PSScriptRoot 'config.example.json') -Raw -Encoding UTF8|ConvertFrom-Json
  if(Test-Path -LiteralPath $configPath){$settings=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json}
  $settings.intervalSeconds=[int]$interval.Value; $settings.publish=$publish.Checked
  [IO.File]::WriteAllText($configPath,($settings|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
  $stopFile=Join-Path $stateDir 'stop'; if(Test-Path -LiteralPath $stopFile){Remove-Item -LiteralPath $stopFile}
  $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
  $script:worker=Start-Process -FilePath $nodePath -ArgumentList @('"'+(Join-Path $PSScriptRoot 'update.mjs')+'"') -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $stateDir ($stamp+'-stdout.log')) -RedirectStandardError (Join-Path $stateDir ($stamp+'-stderr.log'))
  [KeepAwake]::SetThreadExecutionState([uint32]2147483649)|Out-Null
  $info.Text='執行中，最小化視窗後仍持續更新。'
 } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'無法啟動')|Out-Null }
})
$stop.Add_Click({[IO.File]::WriteAllText((Join-Path $stateDir 'stop'),'stop');$info.Text='已要求停止；本輪讀取完成後停止。'})
$sources.Add_Click({Start-Process notepad.exe -ArgumentList @('"'+(Join-Path $PSScriptRoot 'sources.json')+'"')})
$open.Add_Click({Start-Process explorer.exe -ArgumentList @('"'+$stateDir+'"')})
$timer=New-Object System.Windows.Forms.Timer; $timer.Interval=2000
$timer.Add_Tick({
 try {
  if($script:worker -and $script:worker.HasExited){$info.Text='更新器已停止。網站保留最後成功發布的資料。';[KeepAwake]::SetThreadExecutionState([uint32]2147483648)|Out-Null}
  $report=Join-Path $stateDir 'status.json'; if(Test-Path -LiteralPath $report){$r=Get-Content -LiteralPath $report -Raw -Encoding UTF8|ConvertFrom-Json;$log.Text="最後檢查：$($r.at)`r`n週次：$($r.week)`r`n保留筆數：$($r.records)`r`n來源涵蓋：$($r.coverage.configuredStores)/$($r.coverage.totalStores) 家`r`n發布：$($r.publication)`r`n`r`n"+($r.sources|ForEach-Object {"$($_.status)  $($_.sourceUrl)  $($_.error)"}|Out-String)}
 }catch{}
});$timer.Start()
$form.Add_FormClosing({param($sender,$eventArgs)
 if($script:worker -and -not $script:worker.HasExited){$choice=[System.Windows.Forms.MessageBox]::Show('關閉視窗會要求更新器停止。若要人在外面仍持續更新，請按「否」並將視窗最小化。確定停止？','停止更新器','YesNo');if($choice -eq 'No'){$eventArgs.Cancel=$true;return};[IO.File]::WriteAllText((Join-Path $stateDir 'stop'),'stop')}
 [KeepAwake]::SetThreadExecutionState([uint32]2147483648)|Out-Null
})
[void]$form.ShowDialog();$timer.Dispose()
