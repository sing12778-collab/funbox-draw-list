@echo off
setlocal
cd /d "%~dp0.."
set "DRAW_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "DRAW_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
"%DRAW_NODE%" --version
if errorlevel 1 goto missing
echo Keep this window open. Press Ctrl+C to stop. Keep Windows awake.
"%DRAW_NODE%" updater\update.mjs
pause
exit /b
:missing
echo Install Node.js 22 or newer from https://nodejs.org then run again.
pause
